NLRP3 STEP 2 — CLEAN FINAL OUTPUTS
=================================

MAIN DATASETS
-------------
NLRP3_STEP2_FINAL.csv
    Core final dataset after ECFP4/PCA/t-SNE/K-means.

NLRP3_STEP2_COMPLETE_WITH_SCAFFOLDS.csv
    Final complete dataset including scaffold assignments.

FIGURES FOLDER
--------------
FINAL_PCA_Cumulative_Variance_Clean
FINAL_PCA_Chemical_Space
FINAL_tSNE_Bioactivity
FINAL_KMeans_Silhouette
FINAL_tSNE_Clusters_Circled
FINAL_Cluster_Activity_Enrichment
FINAL_Scaffold_Diversity
FINAL_Most_Potent_Compound_Per_Cluster

TABLES FOLDER
-------------
NLRP3_STEP2_verified_input.csv
ECFP4_fingerprints.csv
ECFP4_information.csv
PCA_80percent_components.csv
PCA_explained_variance_80percent.csv
tSNE_coordinates.csv
KMeans_cluster_distribution.csv
KMeans_silhouette_scores.csv
FINAL_Cluster_Activity_Enrichment.csv
FINAL_Scaffold_Summary.csv
FINAL_Top3_Scaffolds_Per_Cluster.csv
FINAL_Scaffold_Diversity_Per_Cluster.csv
FINAL_Cluster_Physicochemical_Activity_Profile.csv
FINAL_Top5_Active_Compounds_Per_Cluster.csv
FINAL_Most_Potent_Compound_Per_Cluster.csv
FINAL_Run_Summary.csv

MODELS FOLDER
-------------
ECFP4_variance_filter.pkl
PCA_80percent_variance.pkl
KMeans_final_model.pkl

ARRAYS FOLDER
-------------
ECFP4_fingerprints.npy
X_ECFP4_nonconstant.npy
X_pca_80percent_variance.npy
X_tSNE.npy

FIXED ACTIVITY DEFINITION
-------------------------
Active   : pIC50 >= 6.0
Inactive : pIC50 <  6.0
Equivalent active cutoff: IC50 <= 1000 nM (1 µM)